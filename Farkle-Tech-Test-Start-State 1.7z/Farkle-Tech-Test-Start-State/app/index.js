import { Farkle } from "./farkle.js";

Farkle.startGame();

// console.log(Farkle.calculateScore([1, 3, 1, 1, 3, 5]))

// console.log(Farkle.calculateScore([1, 1, 2, 4, 2, 3]))
// console.log(Farkle.calculateScore([5, 1, 2, 4, 2, 3]))

// console.log(Farkle.calculateScore([1, 1, 1, 1, 2, 3]))
// console.log(Farkle.calculateScore([1, 1, 1, 1, 1, 2]))
// console.log(Farkle.calculateScore([1, 1, 1, 1, 1, 1]))

// console.log(Farkle.calculateScore([1, 1, 1, 2, 3, 4]))
// console.log(Farkle.calculateScore([2, 2, 2, 3, 4, 4]))
// console.log(Farkle.calculateScore([3, 3, 3, 2, 2, 4]))
// console.log(Farkle.calculateScore([4, 4, 4, 2, 2, 6]))
// console.log(Farkle.calculateScore([5, 5, 5, 2, 2, 4]))
// console.log(Farkle.calculateScore([6, 6, 6, 2, 2, 4]))

// console.log(Farkle.calculateScore([1, 2, 3, 4, 5, 6]))

// console.log(Farkle.calculateScore([1, 1, 1, 1, 2, 2]))
// console.log(Farkle.calculateScore([1, 1, 1, 2, 2, 2]))
// console.log(Farkle.calculateScore([1, 1, 2, 2, 3, 3]))
