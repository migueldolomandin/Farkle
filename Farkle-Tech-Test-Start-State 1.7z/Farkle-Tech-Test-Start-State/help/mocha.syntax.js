describe("Test suite name", () => {
  it("should test something", () => {
    // test data
    // test action/execution
    // assertion
  });

  it("should test another thing", () => {
    // test data
    // test action/execution
    // assertion
  });
});
